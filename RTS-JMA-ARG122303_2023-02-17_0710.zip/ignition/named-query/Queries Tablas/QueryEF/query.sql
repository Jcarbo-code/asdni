SELECT DISTINCT

ef.Name as Descripcion, 
ef.StartTime as Inicio, 
ef.EndTime as Fin
--CAST(ef.Duration AS varchar) as Duration,
--ef.IsAnnotated, 
--ef.CanBeAcknowledged, 
--ef.PrimaryReferencedElement,
--ef.PrimaryReferencedElementID,
--ef.Acknowledged, 
--ef.AcknowledgedBy

FROM [Master].[EventFrame].[EventFrame] AS ef

INNER JOIN
(SELECT 
--CONCAT(Path, CONCAT(' ',Value_String)) as Descripcionea,
ElementID as elementoid
FROM
[Master].[Element].[Attribute]
WHERE ( Name = 'Detalle' )
) as ea

ON elementoid = ef.PrimaryReferencedElementID

WHERE 
(
ef.PrimaryReferencedElementID = '{ElementID}' --AND ef.Name LIKE Concat(Replace('Alarma {SignalAt}','|',''),'%')
)

ORDER BY StartTime Desc