SELECT 
--Min(ACTIVO) as ACTIVO,

--MIN(DAY(StartTime)) as DIAELEGIDO,
--Count(PrimaryReferencedElementID) as Cant,
--' ' as ONTIME,
STRING(DOUBLE(Sum(Duration),minute)) as OFFTIME

FROM [Master].[EventFrame].[EventFrame] as ef

INNER JOIN
(SELECT
CASE
    WHEN replace(SUBSTRING( Path,
		INSTR(Path,'\',1,6)+1, 
		Abs(INSTR(Path,'\',1,7)-INSTR(Path,'\',1,6))
	) ,'\','' ) = '' THEN Name
    ELSE replace(SUBSTRING( Path,
		INSTR(Path,'\',1,6)+1, 
		Abs(INSTR(Path,'\',1,7)-INSTR(Path,'\',1,6))
	) ,'\','' )
END as ACTIVO,

ElementID as ElementIDem
FROM [Master].[Element].[ElementHierarchy]

) as em
ON ef.PrimaryReferencedElementID = ElementIDem

/*MOMENTO INNER JOIN*/
LEFT JOIN
	(SELECT 
	Value as ESTADOIJ,
	Name as NAMEIJ,
	Element as ELEMENTIJ,
	ElementID
	FROM [Master].[Element].[Attribute]) as ea
ON (ea.ElementID = ef.PrimaryReferencedElementID AND NAMEIJ = 'Estado Equipo')
/*MOMENTO INNER JOIN*/

WHERE (
		( StartTime > '{stTime}' )
		AND
		( replace(SUBSTRING( Name,1, Abs(INSTR(Name,' ',1,1))),' ', '') = 'Paro' )
		AND
		ACTIVO = '{Activo}'
		
		)
		
--GROUP BY DAY(StartTime)