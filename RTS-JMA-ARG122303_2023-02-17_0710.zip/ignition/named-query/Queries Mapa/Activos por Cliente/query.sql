SELECT 
Valuecli as Cliente,
Count(Element) as Cantidad
FROM [Master].[Element].[Attribute] as ea1

inner join 
(select 
Value_String as Valuecli, 
ID as elemia 
FROM [Master].[Element].[Attribute]) as ea2
ON ea1.ID = elemia

/*MOMENTO INNER JOIN*/
INNER JOIN
	(SELECT	
		Path as RUTA,
		ElementID as ELEMENTIDIJ,
		replace(SUBSTRING( Path,
		INSTR(Path,'\',1,3)+1, 
		Abs(INSTR(Path,'\',1,4)-INSTR(Path,'\',1,3))
		) ,'\','' ) as DISTRITO,
		CASE
		    WHEN replace(SUBSTRING( Path,
				INSTR(Path,'\',1,6)+1, 
				Abs(INSTR(Path,'\',1,7)-INSTR(Path,'\',1,6))
			) ,'\','' ) = '' THEN Name
		    ELSE replace(SUBSTRING( Path,
				INSTR(Path,'\',1,6)+1, 
				Abs(INSTR(Path,'\',1,7)-INSTR(Path,'\',1,6))
			) ,'\','' )
		END as ACTIVO
	FROM [Master].[Element].[ElementHierarchy]
	WHERE 
	(
		( {Region} AND {level_var}=0 ) --REGION
		OR
		( {Pais} AND {level_var}=1 ) 
		OR
		( {Distrito} AND {level_var}=2 ) 
		OR
		( {Yacimiento} AND {level_var}=3 ) --REGION
		OR
		( {Locacion} AND {level_var}=4 ) 
		OR
		( {Activo} AND {level_var}=5 ) 
		)
		) as em
ON ea1.ElementID = ELEMENTIDIJ
/*MOMENTO INNER JOIN*/

WHERE ( Name LIKE 'Cliente' )

group by Valuecli