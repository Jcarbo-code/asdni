SELECT 
Min(SUBSTRING( Name,1, (INSTR(Name, 'por',1,1))-1)) as Causa,
Count(PrimaryReferencedElementID) as TotalParos,
String(Sum(Duration)) as TiempoTotalParos,
Max(CAST(StartTime as string)) as UltimoParo
--Min(ACTIVO) as ACTIVO

FROM [Master].[EventFrame].[EventFrame] as ef

INNER JOIN
(SELECT
CASE
    WHEN replace(SUBSTRING( Path,
		INSTR(Path,'\',1,6)+1, 
		Abs(INSTR(Path,'\',1,7)-INSTR(Path,'\',1,6))
	) ,'\','' ) = '' THEN Name
    ELSE replace(SUBSTRING( Path,
		INSTR(Path,'\',1,6)+1, 
		Abs(INSTR(Path,'\',1,7)-INSTR(Path,'\',1,6))
	) ,'\','' )
END as ACTIVO,
ElementID as ElementIDem
FROM [Master].[Element].[ElementHierarchy]

) as em
ON ef.PrimaryReferencedElementID = ElementIDem

/*MOMENTO INNER JOIN*/
INNER JOIN
	(SELECT 
	Value_String as ESTADOIJ,
	Name as NAMEIJ,
	Element as ELEMENTIJ,
	ElementID
	FROM [Master].[Element].[Attribute]) as ea
ON (ea.ElementID = ef.PrimaryReferencedElementID AND NAMEIJ = 'Estado Equipo')
/*MOMENTO INNER JOIN*/

WHERE (
		( StartTime > '*-30d' )
		AND
		( replace(SUBSTRING( Name,1, Abs(INSTR(Name,' ',1,1))),' ', '') = 'Paro' )
		AND
		( ACTIVO LIKE '{Activo}' )
		)
		


