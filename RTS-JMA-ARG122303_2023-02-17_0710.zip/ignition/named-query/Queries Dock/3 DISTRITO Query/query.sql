SELECT DISTINCT

/*replace(SUBSTRING( em.Path,
		INSTR(em.Path,'\',1,1)+1, 
		Abs(INSTR(em.Path,'\',1,2)-INSTR(em.Path,'\',1,1))
	) ,'\','' ) as REGION,
	
replace(SUBSTRING( em.Path,
		INSTR(em.Path,'\',1,2)+1, 
		Abs(INSTR(em.Path,'\',1,3)-INSTR(em.Path,'\',1,2))
	) ,'\','' ) as PAIS,*/
	
replace(SUBSTRING( em.Path,
		INSTR(em.Path,'\',1,3)+1, 
		Abs(INSTR(em.Path,'\',1,4)-INSTR(em.Path,'\',1,3))
	) ,'\','' ) as DISTRITO

FROM [Master].[Element].[ElementHierarchy] as em


--WHERE ( Level = 3 AND ( em.Path LIKE '\{var_REG}\{var_PAI}' ) )


WHERE (
		( Level = 3 )
		
		  AND
		  
		  ( {var_PAI} ) --em.Path
	)

ORDER BY DISTRITO