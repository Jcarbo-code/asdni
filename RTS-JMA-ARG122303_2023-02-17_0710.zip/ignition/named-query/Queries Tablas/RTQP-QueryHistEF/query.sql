SELECT DISTINCT

replace(SUBSTRING( em.Path,
		INSTR(em.Path,'\',1,1)+1, 
		Abs(INSTR(em.Path,'\',1,2)-INSTR(em.Path,'\',1,1))
	) ,'\','' ) as REGION,
	
replace(SUBSTRING( em.Path,
		INSTR(em.Path,'\',1,2)+1, 
		Abs(INSTR(em.Path,'\',1,3)-INSTR(em.Path,'\',1,2))
	) ,'\','' ) as PAIS,
	
replace(SUBSTRING( em.Path,
		INSTR(em.Path,'\',1,3)+1, 
		Abs(INSTR(em.Path,'\',1,4)-INSTR(em.Path,'\',1,3))
	) ,'\','' ) as DISTRITO,
	
replace(SUBSTRING( em.Path,
		INSTR(em.Path,'\',1,4)+1, 
		Abs(INSTR(em.Path,'\',1,5)-INSTR(em.Path,'\',1,4))
	) ,'\','' ) as YACIMIENTO,

replace(SUBSTRING( em.Path,
		INSTR(em.Path,'\',1,5)+1, 
		Abs(INSTR(em.Path,'\',1,6)-INSTR(em.Path,'\',1,5))
	) ,'\','' ) as LOCACION,
	
CASE
    WHEN replace(SUBSTRING( em.Path,
		INSTR(em.Path,'\',1,6)+1, 
		Abs(INSTR(em.Path,'\',1,7)-INSTR(em.Path,'\',1,6))
	) ,'\','' ) = '' THEN em.Name
    ELSE replace(SUBSTRING( em.Path,
		INSTR(em.Path,'\',1,6)+1, 
		Abs(INSTR(em.Path,'\',1,7)-INSTR(em.Path,'\',1,6))
	) ,'\','' )
END as ACTIVO,

' ' as EVENTO,

MENSAJE as DESCRIPCION,
--  TSS, SOLO TSS. COLUMNA TSS DE FECHA A STRING PARA QUE EXPORT A EXCEL FUNCIONE CORRECTAMENTE EN FORMATO 
CAST(TSS as string) as TSS,

EFID

--em.ElementID as ElementID,

FROM [Master].[Element].[ElementHierarchy] as em

/*MOMENTO INNER JOIN*/
INNER JOIN
(SELECT 
replace(SUBSTRING( Name,1, Abs(INSTR(Name,' ',1,1))),' ', '') as TIPO, 
SUBSTRING( Name,1, (INSTR(Name, 'por',1,1))-1) as MENSAJE,
StartTime as TSS, --CONVERT(datetime, '2017-08-25'
ID as EFID,
PrimaryReferencedElementID as dato
FROM [Master].[EventFrame].[EventFrame]) as ef
ON dato = em.ElementID
/*MOMENTO INNER JOIN*/

		-- {Region}\{Pais}\{Distrito}\{Yacimiento}\{Locacion}
WHERE (
		(
		( {Region} AND {level_var}=0 ) --REGION
		OR
		( {Pais} AND {level_var}=1 ) 
		OR
		( {Distrito} AND {level_var}=2 )
		OR
		( {Yacimiento} AND {level_var}=3 ) --REGION
		OR
		( {Locacion} AND {level_var}=4 ) 
		OR
		( ({Activo}) AND {level_var}=5 ) 
		)
		
		AND
		( TSS > '{stTime}' )
		
		AND
		( TSS < '{endTime}' )
		
		AND (
		( TIPO LIKE 'Paro' AND {CHKBX_varParo} = 1 ) OR 
		( TIPO LIKE 'Condiciones' AND {CHKBX_varCINS} = 1 ) OR 
		( TIPO LIKE 'Conectividad' AND {CHKBX_varCtvd} = 1 ) OR 
		( TIPO LIKE 'Alarma' AND {CHKBX_varAlrms} = 1 ) 
		)
		
		)

Order by TSS
--GROUP BY ef.PrimaryReferencedElementID, ea.Element, ea.Value_String, em.ElementID, ea.Description, em.Path, ea.Path