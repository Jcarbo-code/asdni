SELECT DISTINCT
Min(REGION) as REGION,
Min(PAIS) as PAIS,
Min(DISTRITO) as DISTRITO,
Min(YACIMIENTO) as YACIMIENTO,
Min(LOCACION) as LOCACION,
Min(ACTIVO) as ACTIVO,
' ' as EVENTO, --esta columna se trae para dibujar un simbolo (ver prototipo)
SUBSTRING( Name,1, (INSTR(Name, 'por',1,1))-1) as DESCRIPCION,
--  TSS, SOLO TSS. COLUMNA TSS DE FECHA A STRING PARA QUE EXPORT A EXCEL FUNCIONE CORRECTAMENTE EN FORMATO 
Max(CAST(StartTime as string)) as TSS,
--Max(StartTime) as TSS,
COUNT(EFHOY) as EFHOY,
COUNT(EFAYE) as EFAYE,
COUNT(EFSEM) as EFSEM,
COUNT(EFMES) as EFMES,
String(SUM(Duration)) as tiempoac

FROM [Master].[EventFrame].[EventFrame] as ef

/*MOMENTO INNER JOIN*/
INNER JOIN
(SELECT 
Path as "em.Path",
replace(SUBSTRING( Path,
		INSTR(Path,'\',1,1)+1, 
		Abs(INSTR(Path,'\',1,2)-INSTR(Path,'\',1,1))
	) ,'\','' ) as REGION,
replace(SUBSTRING( Path,
		INSTR(Path,'\',1,2)+1, 
		Abs(INSTR(Path,'\',1,3)-INSTR(Path,'\',1,2))
	) ,'\','' ) as PAIS,
replace(SUBSTRING( Path,
		INSTR(Path,'\',1,3)+1, 
		Abs(INSTR(Path,'\',1,4)-INSTR(Path,'\',1,3))
	) ,'\','' ) as DISTRITO,
replace(SUBSTRING( Path,
		INSTR(Path,'\',1,4)+1, 
		Abs(INSTR(Path,'\',1,5)-INSTR(Path,'\',1,4))
	) ,'\','' ) as YACIMIENTO,
replace(SUBSTRING( Path,
		INSTR(Path,'\',1,5)+1, 
		Abs(INSTR(Path,'\',1,6)-INSTR(Path,'\',1,5))
	) ,'\','' ) as LOCACION,
CASE
    WHEN replace(SUBSTRING( Path,
		INSTR(Path,'\',1,6)+1, 
		Abs(INSTR(Path,'\',1,7)-INSTR(Path,'\',1,6))
	) ,'\','' ) = '' THEN Name
    ELSE replace(SUBSTRING( Path,
		INSTR(Path,'\',1,6)+1, 
		Abs(INSTR(Path,'\',1,7)-INSTR(Path,'\',1,6))
	) ,'\','' )
END as ACTIVO,


ElementID as Elementem
FROM [Master].[Element].[ElementHierarchy]
WHERE (
		( {Region} AND {level_var}=0 ) --REGION
		OR
		( {Pais} AND {level_var}=1 ) 
		OR
		( {Distrito} AND {level_var}=2 ) 
		OR
		( {Yacimiento} AND {level_var}=3 ) --REGION
		OR
		( {Locacion} AND {level_var}=4 ) 
		OR
		( {Activo} AND {level_var}=5 ) 
	)
) as em

ON Elementem = ef.PrimaryReferencedElementID
/*MOMENTO INNER JOIN*/

LEFT JOIN
	(SELECT
		ID as EFHOY
	FROM [Master].[EventFrame].[EventFrame]
	WHERE StartTime>'t') as efe
ON ( EFHOY = ef.ID )
/*MOMENTO INNER JOIN*/

LEFT JOIN
	(SELECT
		ID as EFAYE
	FROM [Master].[EventFrame].[EventFrame]
	WHERE (StartTime>'y' and StartTime<'t')) as eff
ON ( EFAYE = ef.ID )
/*MOMENTO INNER JOIN*/

LEFT JOIN
	(SELECT
		ID as EFSEM
	FROM [Master].[EventFrame].[EventFrame]
	WHERE StartTime>'*-7d' ) as efg
ON ( EFSEM = ef.ID )
/*MOMENTO INNER JOIN*/

LEFT JOIN
	(SELECT
		ID as EFMES
	FROM [Master].[EventFrame].[EventFrame]
	WHERE StartTime>'*-30d' ) as efh
ON ( EFMES = ef.ID )
/*MOMENTO INNER JOIN*/

WHERE (
		( ef.StartTime > '{stTime}' )
		AND
		( ef.StartTime < '{endTime}' )
		
		AND (
		( replace(SUBSTRING( Name,1, Abs(INSTR(Name,' ',1,1))),' ', '') LIKE 'Paro' AND {CHKBX_varParo} = 1 ) OR 
		( replace(SUBSTRING( Name,1, Abs(INSTR(Name,' ',1,1))),' ', '') LIKE 'Condiciones' AND {CHKBX_varCINS} = 1 ) OR 
		( replace(SUBSTRING( Name,1, Abs(INSTR(Name,' ',1,1))),' ', '') LIKE 'Conectividad' AND {CHKBX_varCtvd} = 1 ) OR 
		( replace(SUBSTRING( Name,1, Abs(INSTR(Name,' ',1,1))),' ', '') LIKE 'Alarma' AND {CHKBX_varAlrms} = 1 ) 
		)
		
		
		)
GROUP BY SUBSTRING( ef.Name,1, (INSTR(ef.Name, 'por',1,1))-1), ACTIVO
Order by TSS

