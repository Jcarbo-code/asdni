SELECT DISTINCT

Min(ACTIVO) as ACTIVO,
SUBSTRING( Name,(INSTR(Name, 'por',1,1))+3, 4) as DESCRIPCION,
--  TSS, SOLO TSS. COLUMNA TSS DE FECHA A STRING PARA QUE EXPORT A EXCEL FUNCIONE CORRECTAMENTE EN FORMATO 
Max(CAST(StartTime as string)) as TSS

FROM [Master].[EventFrame].[EventFrame] as ef

/*MOMENTO INNER JOIN*/
INNER JOIN
(SELECT 
CASE
    WHEN replace(SUBSTRING( Path,
		INSTR(Path,'\',1,6)+1, 
		Abs(INSTR(Path,'\',1,7)-INSTR(Path,'\',1,6))
	) ,'\','' ) = '' THEN Name
    ELSE replace(SUBSTRING( Path,
		INSTR(Path,'\',1,6)+1, 
		Abs(INSTR(Path,'\',1,7)-INSTR(Path,'\',1,6))
	) ,'\','' )
END as ACTIVO,
ElementID as Elementem
FROM [Master].[Element].[ElementHierarchy]
WHERE (
		( {Region} AND {level_var}=0 ) --REGION
		OR
		( {Pais} AND {level_var}=1 ) 
		OR
		( {Distrito} AND {level_var}=2 ) 
		OR
		( {Yacimiento} AND {level_var}=3 ) --REGION
		OR
		( {Locacion} AND {level_var}=4 ) 
		OR
		( ({Activo}) AND {level_var}=5 ) 
	)
) as em
ON Elementem = ef.PrimaryReferencedElementID
/*MOMENTO INNER JOIN*/

		-- {Region}\{Pais}\{Distrito}\{Yacimiento}\{Locacion}
WHERE (
	( Acknowledged is null )
	AND
	( EndTime is null )
	)

GROUP BY ACTIVO, SUBSTRING( Name,(INSTR(Name, 'por',1,1))+3, 4)
Order by ACTIVO
