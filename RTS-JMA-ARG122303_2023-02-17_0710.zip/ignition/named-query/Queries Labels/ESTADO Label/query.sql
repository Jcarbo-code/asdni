SELECT
Path, 
Name,
ESTADOIJ

FROM [Master].[Element].[ElementHierarchy] as em

INNER JOIN
	(SELECT 
	Value as ESTADOIJ,
	Name as NAMEIJ,
	Element as ELEMENTIJ,
	ElementID
	FROM [Master].[Element].[Attribute]) as ea
ON (ea.ElementID = em.ElementID AND NAMEIJ = 'Estado Equipo')

WHERE Level = 5 AND Name = '{myActivo}'