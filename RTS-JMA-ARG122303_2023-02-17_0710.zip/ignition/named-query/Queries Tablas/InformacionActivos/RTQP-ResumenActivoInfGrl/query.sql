-- Attribute table.
-- Returns element attributes.
SELECT Concat(Name,Concat(' - ', Element)) as Name, Value,
PAIS, DISTRITO, YACIMIENTO, LOCACION
FROM [Master].[Element].[Attribute] as ea

/*MOMENTO INNER JOIN*/
INNER JOIN
	(SELECT	
		ElementID as ELEMENTIDIJ,
		replace(SUBSTRING( Path,
		INSTR(Path,'\',1,2)+1, 
		Abs(INSTR(Path,'\',1,3)-INSTR(Path,'\',1,2))
	) ,'\','' ) as PAIS,
replace(SUBSTRING( Path,
		INSTR(Path,'\',1,3)+1, 
		Abs(INSTR(Path,'\',1,4)-INSTR(Path,'\',1,3))
	) ,'\','' ) as DISTRITO,
replace(SUBSTRING( Path,
		INSTR(Path,'\',1,4)+1, 
		Abs(INSTR(Path,'\',1,5)-INSTR(Path,'\',1,4))
	) ,'\','' ) as YACIMIENTO,
replace(SUBSTRING( Path,
		INSTR(Path,'\',1,5)+1, 
		Abs(INSTR(Path,'\',1,6)-INSTR(Path,'\',1,5))
	) ,'\','' ) as LOCACION,
CASE
    WHEN replace(SUBSTRING( Path,
		INSTR(Path,'\',1,6)+1, 
		Abs(INSTR(Path,'\',1,7)-INSTR(Path,'\',1,6))
	) ,'\','' ) = '' THEN Name
    ELSE replace(SUBSTRING( Path,
		INSTR(Path,'\',1,6)+1, 
		Abs(INSTR(Path,'\',1,7)-INSTR(Path,'\',1,6))
	) ,'\','' )
END as ACTIVO
	FROM [Master].[Element].[ElementHierarchy]) as em
ON ea.ElementID = ELEMENTIDIJ
/*MOMENTO INNER JOIN*/

WHERE (
( ACTIVO LIKE '{myActivo}' )
AND
(
( Name LIKE 'Marca Motor' )
OR
( Name LIKE 'Modelo Motor' )
OR
( Name LIKE 'Marca Cooler' )
OR
( Name LIKE 'Modelo Cooler' )
OR
( Name LIKE 'Potencia Motor' )
OR
( Name LIKE 'Cliente' )
OR
( Name LIKE 'Marca Compresor' )
OR
( Name LIKE 'Modelo Compresor' )
)

)