SELECT 
Double(Sum(Duration), minute) as minutosTotalParos
FROM [Master].[EventFrame].[EventFrame] as ef

INNER JOIN
(SELECT
CASE
    WHEN replace(SUBSTRING( Path,
		INSTR(Path,'\',1,6)+1, 
		Abs(INSTR(Path,'\',1,7)-INSTR(Path,'\',1,6))
	) ,'\','' ) = '' THEN Name
    ELSE replace(SUBSTRING( Path,
		INSTR(Path,'\',1,6)+1, 
		Abs(INSTR(Path,'\',1,7)-INSTR(Path,'\',1,6))
	) ,'\','' )
END as ACTIVO,
ElementID as ElementIDem
FROM [Master].[Element].[ElementHierarchy]
WHERE
	(
		( {Region} AND {level_var}=0 ) --REGION
		OR
		( {Pais} AND {level_var}=1 ) 
		OR
		( {Distrito} AND {level_var}=2 ) 
		OR
		( {Yacimiento} AND {level_var}=3 ) --REGION
		OR
		( {Locacion} AND {level_var}=4 ) 
		OR
		( {Activo} AND {level_var}=5 ) 
	)
) as em
ON ef.PrimaryReferencedElementID = ElementIDem --los activos no detenidos en los ult 30d, no son listados

WHERE ( 
( StartTime > '*-30d' )
AND
( replace(SUBSTRING( Name,1, Abs(INSTR(Name,' ',1,1))),' ', '') = 'Paro' )
)

