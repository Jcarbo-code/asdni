SELECT DISTINCT
Count(ElementID)*30*24*60 as totalMinutos
FROM [Master].[Element].[ElementHierarchy]

WHERE LEVEL = 5