SELECT TOP 1
CONCAT(CONCAT(Path, Name),'\%') as camino
FROM ElementHierarchy
WHERE Name LIKE '{Activo}'