SELECT TOP 1

REGION,
PAIS,
DISTRITO,
LOCACION,
YACIMIENTO,
ACTIVO

FROM [Master].[Element].[Attribute] as ea

INNER JOIN
(SELECT
replace(SUBSTRING( Path,
		INSTR(Path,'\',1,1)+1, 
		Abs(INSTR(Path,'\',1,2)-INSTR(Path,'\',1,1))
	) ,'\','' ) as REGION,

replace(SUBSTRING( Path,
		INSTR(Path,'\',1,2)+1, 
		Abs(INSTR(Path,'\',1,3)-INSTR(Path,'\',1,2))
	) ,'\','' ) as PAIS,
	
replace(SUBSTRING( Path,
		INSTR(Path,'\',1,3)+1, 
		Abs(INSTR(Path,'\',1,4)-INSTR(Path,'\',1,3))
	) ,'\','' ) as DISTRITO,

replace(SUBSTRING( Path,
		INSTR(Path,'\',1,5)+1, 
		Abs(INSTR(Path,'\',1,6)-INSTR(Path,'\',1,5))
	) ,'\','' ) as LOCACION,

replace(SUBSTRING( Path,
		INSTR(Path,'\',1,4)+1, 
		Abs(INSTR(Path,'\',1,5)-INSTR(Path,'\',1,4))
	) ,'\','' ) as YACIMIENTO,
	
CASE
    WHEN replace(SUBSTRING( Path,
		INSTR(Path,'\',1,6)+1, 
		Abs(INSTR(Path,'\',1,7)-INSTR(Path,'\',1,6))
	) ,'\','' ) = '' THEN Name
    ELSE replace(SUBSTRING( Path,
		INSTR(Path,'\',1,6)+1, 
		Abs(INSTR(Path,'\',1,7)-INSTR(Path,'\',1,6))
	) ,'\','' )
END as ACTIVO

FROM [Master].[Element].[ElementHierarchy]) as em
ON ea.ElementID = ElementID

Where ea.Name Like 'Unidad' AND ACTIVO LIKE '{myActivo}'

		-- {Region}\{Pais}\{Distrito}\{Yacimiento}\{Locacion}

