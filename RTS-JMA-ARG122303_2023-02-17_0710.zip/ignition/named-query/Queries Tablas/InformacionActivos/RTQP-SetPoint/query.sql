-- Attribute table.
-- Returns element attributes.
SELECT 
concat(concat(ea.Name, ' | '), Elementito) as Name, 
' ' as Shortname,
LoLo, 
Lo, 
Hi, 
HiHi, 
Value_Double as Value
FROM [Master].[Element].[Attribute] as ea

/*MOMENTO INNER JOIN*/
INNER JOIN
	(SELECT	
		Path as RUTA,
		Name as Elementito,
		ElementID as ELEMENTIDIJ,
		CASE
		    WHEN replace(SUBSTRING( Path,
				INSTR(Path,'\',1,6)+1, 
				Abs(INSTR(Path,'\',1,7)-INSTR(Path,'\',1,6))
			) ,'\','' ) = '' THEN Name
		    ELSE replace(SUBSTRING( Path,
				INSTR(Path,'\',1,6)+1, 
				Abs(INSTR(Path,'\',1,7)-INSTR(Path,'\',1,6))
			) ,'\','' )
		END as ACTIVO
	FROM [Master].[Element].[ElementHierarchy]) as em
ON ea.ElementID = ELEMENTIDIJ
/*MOMENTO INNER JOIN*/

/*MOMENTO INNER JOIN*/
INNER JOIN
	(SELECT
		ElementID as ELEMENTIDL,
		Value_Double as Lo,
		Name as NOMBRE,
		Path as CAMINO
	FROM [Master].[Element].[Attribute]
	WHERE Value_Double is not null) as el
ON ( ea.ElementID = ELEMENTIDL AND NOMBRE LIKE 'Lo' AND Concat(Concat('|', ea.Name), '|') LIKE CAMINO )
/*MOMENTO INNER JOIN*/

/*MOMENTO INNER JOIN*/
INNER JOIN
	(SELECT
		ElementID as ELEMENTIDLL,
		Value_Double as LoLo,
		Name as NOMBRELL,
		Path as CAMINOLL
	FROM [Master].[Element].[Attribute]
	WHERE Value_Double is not null) as ell
ON ( ea.ElementID = ELEMENTIDLL AND NOMBRELL LIKE 'LoLo' AND Concat(Concat('|', ea.Name), '|') LIKE CAMINOLL )
/*MOMENTO INNER JOIN*/

/*MOMENTO INNER JOIN*/
INNER JOIN
	(SELECT
		ElementID as ELEMENTIDH,
		Value_Double as Hi,
		Name as NOMBREH,
		Path as CAMINOH
	FROM [Master].[Element].[Attribute]
	WHERE Value_Double is not null) as eh
ON ( ea.ElementID = ELEMENTIDH AND NOMBREH LIKE 'Hi' AND Concat(Concat('|', ea.Name), '|') LIKE CAMINOH )
/*MOMENTO INNER JOIN*/

/*MOMENTO INNER JOIN*/
INNER JOIN
	(SELECT
		ElementID as ELEMENTIDHH,
		Value_Double as HiHi,
		Name as NOMBREHH,
		Path as CAMINOHH
	FROM [Master].[Element].[Attribute]
	WHERE Value_Double is not null) as ehh
ON ( ea.ElementID = ELEMENTIDHH AND NOMBREHH LIKE 'HiHi' AND Concat(Concat('|', ea.Name), '|') LIKE CAMINOHH )
/*MOMENTO INNER JOIN*/


WHERE (

( ACTIVO LIKE '{myActivo}' )
AND
( ea.Name NOT LIKE 'LoLo' )
AND
( ea.Name NOT LIKE 'Hi' )
AND
( ea.Name NOT LIKE 'HiHi' )
AND
( ea.Name NOT LIKE 'Alarma' )  
AND
( ea.Name NOT LIKE 'Detalle' )
AND
( ea.Name NOT LIKE 'Unidad' )
AND
( ea.Name NOT LIKE 'Activo' )
AND
( ea.Name NOT LIKE 'Downtag' )
AND
( ea.Name NOT LIKE 'Lo' )
AND
( Value_Double is not null )

)

ORDER BY ea.Name