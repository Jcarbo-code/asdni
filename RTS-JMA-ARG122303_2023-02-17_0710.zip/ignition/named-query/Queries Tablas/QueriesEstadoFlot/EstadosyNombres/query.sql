SELECT
replace(SUBSTRING( em.Path,
		INSTR(em.Path,'\',1,5)+1, 
		Abs(INSTR(em.Path,'\',1,6)-INSTR(em.Path,'\',1,5))
	) ,'\','' ) as LOCACION,
	
replace(SUBSTRING( em.Path,
		INSTR(em.Path,'\',1,3)+1, 
		Abs(INSTR(em.Path,'\',1,4)-INSTR(em.Path,'\',1,3))
	) ,'\','' ) as DISTRITO,
CASE
    WHEN replace(SUBSTRING( em.Path,
		INSTR(em.Path,'\',1,6)+1, 
		Abs(INSTR(em.Path,'\',1,7)-INSTR(em.Path,'\',1,6))
	) ,'\','' ) = '' THEN em.Name
    ELSE replace(SUBSTRING( em.Path,
		INSTR(em.Path,'\',1,6)+1, 
		Abs(INSTR(em.Path,'\',1,7)-INSTR(em.Path,'\',1,6))
	) ,'\','' )
END as ACTIVO,
ESTADOIJ

FROM [Master].[Element].[ElementHierarchy] as em

/*MOMENTO INNER JOIN*/
LEFT JOIN
	(SELECT 
	Value as ESTADOIJ,
	Name as NAMEIJ,
	Element as ELEMENTIJ,
	ElementID
	FROM [Master].[Element].[Attribute]) as ea
ON (ea.ElementID = em.ElementID AND NAMEIJ = 'Estado Equipo')
/*MOMENTO INNER JOIN*/

/*MOMENTO INNER JOIN*/
LEFT JOIN
	(SELECT 
	Value as CONEXION,
	Name as NAMECX,
	Element as ELEMENTCX,
	ElementID
	FROM [Master].[Element].[Attribute]) as ecx
ON (ecx.ElementID = em.ElementID AND NAMECX = 'Señal GRD GPRS/GSM')
/*MOMENTO INNER JOIN*/


WHERE (
		(
		( {Region} AND {level_var}=0 ) --REGION
		OR
		( {Pais} AND {level_var}=1 ) 
		OR
		( {Distrito} AND {level_var}=2 ) 
		OR
		( {Yacimiento} AND {level_var}=3 ) --REGION
		OR
		( {Locacion} AND {level_var}=4 ) 
		OR
		(( {Activo} ) AND {level_var} =5)
		
		
		
		)
		AND
		( ESTADOIJ is not null )
	)
	
ORDER BY DISTRITO, ESTADOIJ