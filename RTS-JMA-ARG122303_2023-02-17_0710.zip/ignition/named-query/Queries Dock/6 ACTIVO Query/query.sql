SELECT DISTINCT

/*replace(SUBSTRING( em.Path,
		INSTR(em.Path,'\',1,1)+1, 
		Abs(INSTR(em.Path,'\',1,2)-INSTR(em.Path,'\',1,1))
	) ,'\','' ) as REGION,
	
replace(SUBSTRING( em.Path,
		INSTR(em.Path,'\',1,2)+1, 
		Abs(INSTR(em.Path,'\',1,3)-INSTR(em.Path,'\',1,2))
	) ,'\','' ) as PAIS,
	
replace(SUBSTRING( em.Path,
		INSTR(em.Path,'\',1,3)+1, 
		Abs(INSTR(em.Path,'\',1,4)-INSTR(em.Path,'\',1,3))
	) ,'\','' ) as DISTRITO,
	
replace(SUBSTRING( em.Path,
		INSTR(em.Path,'\',1,4)+1, 
		Abs(INSTR(em.Path,'\',1,5)-INSTR(em.Path,'\',1,4))
	) ,'\','' ) as YACIMIENTO,

replace(SUBSTRING( em.Path,
		INSTR(em.Path,'\',1,5)+1, 
		Abs(INSTR(em.Path,'\',1,6)-INSTR(em.Path,'\',1,5))
	) ,'\','' ) as LOCACION,*/
	
CASE
    WHEN replace(SUBSTRING( em.Path,
		INSTR(em.Path,'\',1,6)+1, 
		Abs(INSTR(em.Path,'\',1,7)-INSTR(em.Path,'\',1,6))
	) ,'\','' ) = '' THEN ea.Element
    ELSE replace(SUBSTRING( em.Path,
		INSTR(em.Path,'\',1,6)+1, 
		Abs(INSTR(em.Path,'\',1,7)-INSTR(em.Path,'\',1,6))
	) ,'\','' )
END as ACTIVO

FROM [Master].[Element].[ElementHierarchy] as em

/*MOMENTO INNER JOIN*/
INNER JOIN
	[Master].[Element].[Attribute] as ea
ON ea.ElementID = em.ElementID
/*MOMENTO INNER JOIN*/

WHERE (
		( Level = 6 )
		
		  AND
		  
		  ( {var_LOC} ) --em.Path
	)

ORDER BY ACTIVO