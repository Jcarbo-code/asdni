SELECT

ESTADOIJ,
CONEXION,
replace(SUBSTRING( em.Path,
		INSTR(em.Path,'\',1,1)+1, 
		Abs(INSTR(em.Path,'\',1,2)-INSTR(em.Path,'\',1,1))
	) ,'\','' ) as REGION,
	
replace(SUBSTRING( em.Path,
		INSTR(em.Path,'\',1,2)+1, 
		Abs(INSTR(em.Path,'\',1,3)-INSTR(em.Path,'\',1,2))
	) ,'\','' ) as PAIS,
	
replace(SUBSTRING( em.Path,
		INSTR(em.Path,'\',1,3)+1, 
		Abs(INSTR(em.Path,'\',1,4)-INSTR(em.Path,'\',1,3))
	) ,'\','' ) as DISTRITO,
	
replace(SUBSTRING( em.Path,
		INSTR(em.Path,'\',1,4)+1, 
		Abs(INSTR(em.Path,'\',1,5)-INSTR(em.Path,'\',1,4))
	) ,'\','' ) as YACIMIENTO,
	
replace(SUBSTRING( em.Path,
		INSTR(em.Path,'\',1,5)+1, 
		Abs(INSTR(em.Path,'\',1,6)-INSTR(em.Path,'\',1,5))
	) ,'\','' ) as LOCACION,
	
CASE
    WHEN replace(SUBSTRING( em.Path,
		INSTR(em.Path,'\',1,6)+1, 
		Abs(INSTR(em.Path,'\',1,7)-INSTR(em.Path,'\',1,6))
	) ,'\','' ) = '' THEN em.Name
    ELSE replace(SUBSTRING( em.Path,
		INSTR(em.Path,'\',1,6)+1, 
		Abs(INSTR(em.Path,'\',1,7)-INSTR(em.Path,'\',1,6))
	) ,'\','' )
END as ACTIVO,

CLIENTE,

HSMARCHAIJ,

' ' as VARIABLES,
' ' as SETPOINTS,
' ' as TENDENCIAS,
' ' as DATOSTECNICOS

--em.ElementID as ElementID

FROM [Master].[Element].[ElementHierarchy] as em


/*MOMENTO INNER JOIN*/
INNER JOIN
	(SELECT 
	Value_Double as HSMARCHAIJ,
	Name as NAMEHS,
	ElementID as ELEMENTIDHS
	FROM [Master].[Element].[Attribute]) as eb
ON (ELEMENTIDHS = em.ElementID AND NAMEHS = 'Horas de Marcha Totales'  )
/*MOMENTO INNER JOIN*/

/*MOMENTO INNER JOIN*/
INNER JOIN
	(SELECT 
	Value as CLIENTE,
	Name as CLIENTENAME,
	ElementID as ELEMENTIDHSb
	FROM [Master].[Element].[Attribute]) as ec
ON (ELEMENTIDHSb = em.ElementID AND CLIENTENAME = 'Cliente'  )
/*MOMENTO INNER JOIN*/

/*MOMENTO INNER JOIN*/
LEFT JOIN
	(SELECT 
	Value as ESTADOIJ,
	Name as NAMEIJ,
	Element as ELEMENTIJ,
	ElementID
	FROM [Master].[Element].[Attribute]) as ea
ON (ea.ElementID = em.ElementID AND NAMEIJ = 'Estado Equipo')
/*MOMENTO INNER JOIN*/

/*MOMENTO INNER JOIN*/
LEFT JOIN
	(SELECT 
	Value as CONEXION,
	Name as NAMECX,
	Element as ELEMENTCX,
	ElementID
	FROM [Master].[Element].[Attribute]) as ecx
ON (ecx.ElementID = em.ElementID AND NAMECX = 'Señal GRD GPRS/GSM')
/*MOMENTO INNER JOIN*/



WHERE (
		(
		( {Region} AND {level_var}=0 ) --REGION
		OR
		( {Pais} AND {level_var}=1 ) 
		OR
		( {Distrito} AND {level_var}=2 ) 
		OR
		( {Yacimiento} AND {level_var}=3 ) --REGION
		OR
		( {Locacion} AND {level_var}=4 ) 
		OR
		(( {Activo} ) AND {level_var} =5)
		
		
		
		)
	)
	order by ACTIVO 
	--group by ac
	
	