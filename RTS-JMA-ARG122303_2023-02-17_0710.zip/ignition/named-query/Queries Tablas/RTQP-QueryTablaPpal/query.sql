SELECT DISTINCT TOP 1000
replace(SUBSTRING( em.Path,
		INSTR(em.Path,'\',1,2)+1, 
		Abs(INSTR(em.Path,'\',1,3)-INSTR(em.Path,'\',1,2))
	) ,'\','' ) as PAIS,

replace(SUBSTRING( em.Path,
		INSTR(em.Path,'\',1,5)+1, 
		Abs(INSTR(em.Path,'\',1,6)-INSTR(em.Path,'\',1,5))
	) ,'\','' ) as LOCACION,

CASE
    WHEN replace(SUBSTRING( em.Path,
		INSTR(em.Path,'\',1,6)+1, 
		Abs(INSTR(em.Path,'\',1,7)-INSTR(em.Path,'\',1,6))
	) ,'\','' ) = '' THEN ea.Element
    ELSE replace(SUBSTRING( em.Path,
		INSTR(em.Path,'\',1,6)+1, 
		Abs(INSTR(em.Path,'\',1,7)-INSTR(em.Path,'\',1,6))
	) ,'\','' )
END as ACTIVO,

MENSAJE,

TSS,

em.ElementID,

EFID --SIRVE EN ESTA QUERY?

FROM [Master].[Element].[ElementHierarchy] as em

/*MOMENTO INNER JOIN*/
INNER JOIN
	[Master].[Element].[Attribute] as ea
ON ea.ElementID = em.ElementID AND ea.Name = 'Detalle'
/*MOMENTO INNER JOIN*/

/*MOMENTO INNER JOIN*/
INNER JOIN
(SELECT 
replace(SUBSTRING( Name,1, Abs(INSTR(Name,' ',1,1))),' ', '') as TIPO, 
Name as MENSAJE,
StartTime as TSS,
ID as EFID,
PrimaryReferencedElementID as dato
FROM [Master].[EventFrame].[EventFrame]) as ef
ON dato = em.ElementID
/*MOMENTO INNER JOIN*/

		-- {Region}\{Pais}\{Distrito}\{Yacimiento}\{Locacion}
WHERE (
		(
		( {Region} AND {level_var}=0 ) --REGION
		OR
		( {Pais} AND {level_var}=1 ) 
		OR
		( {Distrito} AND {level_var}=2 ) 
		OR
		( {Yacimiento} AND {level_var}=3 ) --REGION
		OR
		( {Locacion} AND {level_var}=4 ) 
		OR
		( {Activo} AND {level_var}=5 ) 
		)

		AND (
		( TIPO LIKE 'Paro' AND {CHKBX_varParo} = 1 ) OR 
		( TIPO LIKE 'Condiciones' AND {CHKBX_varCINS} = 1 ) OR 
		( TIPO LIKE 'Conectividad' AND {CHKBX_varCtvd} = 1 ) OR 
		( TIPO LIKE 'Alarma' AND {CHKBX_varAlrms} = 1 ) 
		)
	)

Order by TSS DESC