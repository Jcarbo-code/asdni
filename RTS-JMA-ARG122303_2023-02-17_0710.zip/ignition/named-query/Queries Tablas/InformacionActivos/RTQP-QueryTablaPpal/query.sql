SELECT DISTINCT

Min(PAIS) as PAIS,
Min(LOCACION) as LOCACION,
Min(ACTIVO) as ACTIVO,
' ' as EVENTO,
Min(SUBSTRING( Name,1, (INSTR(Name, 'por',1,1))-1)) as DESCRIPCION,
Max(StartTime) as TSS,
' ' as DETALLE,
COUNT(ID) as Cant

FROM [Master].[EventFrame].[EventFrame] as ef

/*MOMENTO INNER JOIN*/
INNER JOIN
(SELECT 
replace(SUBSTRING( Path,
		INSTR(Path,'\',1,2)+1, 
		Abs(INSTR(Path,'\',1,3)-INSTR(Path,'\',1,2))
	) ,'\','' ) as PAIS,
replace(SUBSTRING( Path,
		INSTR(Path,'\',1,3)+1, 
		Abs(INSTR(Path,'\',1,4)-INSTR(Path,'\',1,3))
	) ,'\','' ) as DISTRITO,
replace(SUBSTRING( Path,
		INSTR(Path,'\',1,4)+1, 
		Abs(INSTR(Path,'\',1,5)-INSTR(Path,'\',1,4))
	) ,'\','' ) as YACIMIENTO,
replace(SUBSTRING( Path,
		INSTR(Path,'\',1,5)+1, 
		Abs(INSTR(Path,'\',1,6)-INSTR(Path,'\',1,5))
	) ,'\','' ) as LOCACION,
CASE
    WHEN replace(SUBSTRING( Path,
		INSTR(Path,'\',1,6)+1, 
		Abs(INSTR(Path,'\',1,7)-INSTR(Path,'\',1,6))
	) ,'\','' ) = '' THEN Name
    ELSE replace(SUBSTRING( Path,
		INSTR(Path,'\',1,6)+1, 
		Abs(INSTR(Path,'\',1,7)-INSTR(Path,'\',1,6))
	) ,'\','' )
END as ACTIVO,
ElementID as Elementem
FROM [Master].[Element].[ElementHierarchy]
WHERE (
		( {Region} AND {level_var}=0 ) --REGION
		OR
		( {Pais} AND {level_var}=1 ) 
		OR
		( {Distrito} AND {level_var}=2 ) 
		OR
		( {Yacimiento} AND {level_var}=3 ) --REGION
		OR
		( {Locacion} AND {level_var}=4 ) 
		OR
		( ({Activo}) AND {level_var}=5 ) 
	)
) as em
ON Elementem = ef.PrimaryReferencedElementID
/*MOMENTO INNER JOIN*/





		-- {Region}\{Pais}\{Distrito}\{Yacimiento}\{Locacion}
WHERE (
		(
		( replace(SUBSTRING( Name,1, Abs(INSTR(Name,' ',1,1))),' ', '') LIKE 'Paro' AND {CHKBX_varParo} = 1 ) OR 
		( replace(SUBSTRING( Name,1, Abs(INSTR(Name,' ',1,1))),' ', '') LIKE 'Condiciones' AND {CHKBX_varCINS} = 1 ) OR 
		( replace(SUBSTRING( Name,1, Abs(INSTR(Name,' ',1,1))),' ', '') LIKE 'Conectividad' AND {CHKBX_varCtvd} = 1 ) OR 
		( replace(SUBSTRING( Name,1, Abs(INSTR(Name,' ',1,1))),' ', '') LIKE 'Alarma' AND {CHKBX_varAlrms} = 1 ) 
		)
	AND
	( Acknowledged is null )
	)

GROUP BY ACTIVO
Order by TSS DESC
