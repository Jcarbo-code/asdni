SELECT DISTINCT
	
/*replace(SUBSTRING( em.Path,
		INSTR(em.Path,'\',1,1)+1, 
		Abs(INSTR(em.Path,'\',1,2)-INSTR(em.Path,'\',1,1))
	) ,'\','' ) as REGION,
	
replace(SUBSTRING( em.Path,
		INSTR(em.Path,'\',1,2)+1, 
		Abs(INSTR(em.Path,'\',1,3)-INSTR(em.Path,'\',1,2))
	) ,'\','' ) as PAIS,
	
replace(SUBSTRING( em.Path,
		INSTR(em.Path,'\',1,3)+1, 
		Abs(INSTR(em.Path,'\',1,4)-INSTR(em.Path,'\',1,3))
	) ,'\','' ) as DISTRITO,*/
	
replace(SUBSTRING( em.Path,
		INSTR(em.Path,'\',1,4)+1, 
		Abs(INSTR(em.Path,'\',1,5)-INSTR(em.Path,'\',1,4))
	) ,'\','' ) as YACIMIENTO

FROM [Master].[Element].[ElementHierarchy] as em

--WHERE ( Level = 4 AND ( em.Path LIKE '\{var_REG}\{var_PAI}\{var_DIS}' ) )


WHERE (
		( Level = 4 )
		
		  AND
		  
		  ( {var_DIS} ) --em.Path
	)

ORDER BY YACIMIENTO