SELECT 
Min(REGION) as REGION,
Min(PAIS) as PAIS,
Min(DISTRITO) as DISTRITO,
Min(YACIMIENTO) as YACIMIENTO,
Min(LOCACION) as LOCACION,
Min(ACTIVO) as ACTIVO,
' ' as ESTADO,
Count(PrimaryReferencedElementID) as TotalParos,
String(Sum(Duration)) as TiempoTotalParos,
Max(StartTime) as UltimoParo,
Min(SUBSTRING( Name,1, (INSTR(Name, 'por',1,1))-1)) as Causa
FROM [Master].[EventFrame].[EventFrame] as ef

INNER JOIN
(SELECT
replace(SUBSTRING( Path,
		INSTR(Path,'\',1,1)+1, 
		Abs(INSTR(Path,'\',1,2)-INSTR(Path,'\',1,1))
	) ,'\','' ) as REGION,
	
replace(SUBSTRING( Path,
		INSTR(Path,'\',1,2)+1, 
		Abs(INSTR(Path,'\',1,3)-INSTR(Path,'\',1,2))
	) ,'\','' ) as PAIS,
	
replace(SUBSTRING( Path,
		INSTR(Path,'\',1,3)+1, 
		Abs(INSTR(Path,'\',1,4)-INSTR(Path,'\',1,3))
	) ,'\','' ) as DISTRITO,
	
replace(SUBSTRING( Path,
		INSTR(Path,'\',1,4)+1, 
		Abs(INSTR(Path,'\',1,5)-INSTR(Path,'\',1,4))
	) ,'\','' ) as YACIMIENTO,

replace(SUBSTRING( Path,
		INSTR(Path,'\',1,5)+1, 
		Abs(INSTR(Path,'\',1,6)-INSTR(Path,'\',1,5))
	) ,'\','' ) as LOCACION,

CASE
    WHEN replace(SUBSTRING( Path,
		INSTR(Path,'\',1,6)+1, 
		Abs(INSTR(Path,'\',1,7)-INSTR(Path,'\',1,6))
	) ,'\','' ) = '' THEN Name
    ELSE replace(SUBSTRING( Path,
		INSTR(Path,'\',1,6)+1, 
		Abs(INSTR(Path,'\',1,7)-INSTR(Path,'\',1,6))
	) ,'\','' )
END as ACTIVO,
ElementID as ElementIDem
FROM [Master].[Element].[ElementHierarchy]
WHERE
	(
		( {Region} AND {level_var}=0 ) --REGION
		OR
		( {Pais} AND {level_var}=1 ) 
		OR
		( {Distrito} AND {level_var}=2 ) 
		OR
		( {Yacimiento} AND {level_var}=3 ) --REGION
		OR
		( {Locacion} AND {level_var}=4 ) 
		OR
		( {Activo} AND {level_var}=5 ) 
	)
) as em
ON ef.PrimaryReferencedElementID = ElementIDem

/*MOMENTO INNER JOIN*/
LEFT JOIN
	(SELECT 
	Value as ESTADOIJ,
	Name as NAMEIJ,
	Element as ELEMENTIJ,
	ElementID
	FROM [Master].[Element].[Attribute]) as ea
ON (ea.ElementID = ef.PrimaryReferencedElementID AND NAMEIJ = 'Estado Equipo')
/*MOMENTO INNER JOIN*/

WHERE (
		( StartTime > '{stTime}' )
		
		AND
		( StartTime < '{endTime}' )
		
		AND
		( replace(SUBSTRING( Name,1, Abs(INSTR(Name,' ',1,1))),' ', '') = 'Paro' )
		
		)
		
GROUP BY ACTIVO

