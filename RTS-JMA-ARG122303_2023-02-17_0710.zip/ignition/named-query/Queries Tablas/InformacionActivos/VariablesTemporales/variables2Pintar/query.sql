SELECT 
--eh.Name Element, 
a.Name Attribute,
a.UnitOfMeasure UOM, 
SUBSTRING(string(sv.TimeStamp),1,16) myTiempo, 
CASE 
WHEN  ROUND (DOUBLE(sv.Value), 2) is not null
	THEN  ROUND (DOUBLE(sv.Value), 2)
ELSE -1
END as Value,
LoLo, 
Lo, 
Hi, 
HiHi
FROM Master.Element.ElementHierarchy eh

INNER JOIN Master.Element.Attribute a ON a.ElementID = eh.ElementID
CROSS APPLY Master.Element.GetSampledValues (a.ID, '{stTime}', '{endTime}', '{intervalo}') sv

/*MOMENTO INNER JOIN*/
INNER JOIN
	(SELECT
		ElementID as ELEMENTIDL,
		Value_Double as Lo,
		Name as NOMBRE,
		Path as CAMINO
	FROM [Master].[Element].[Attribute]) as el
ON ( a.ElementID = ELEMENTIDL AND NOMBRE LIKE 'Lo' AND Concat(Concat('|', a.Name), '|') LIKE CAMINO )
/*MOMENTO INNER JOIN*/

/*MOMENTO INNER JOIN*/
INNER JOIN
	(SELECT
		ElementID as ELEMENTIDLL,
		Value_Double as LoLo,
		Name as NOMBRELL,
		Path as CAMINOLL
	FROM [Master].[Element].[Attribute]) as ell
ON ( a.ElementID = ELEMENTIDLL AND NOMBRELL LIKE 'LoLo' AND Concat(Concat('|', a.Name), '|') LIKE CAMINOLL )
/*MOMENTO INNER JOIN*/

/*MOMENTO INNER JOIN*/
INNER JOIN
	(SELECT
		ElementID as ELEMENTIDH,
		Value_Double as Hi,
		Name as NOMBREH,
		Path as CAMINOH
	FROM [Master].[Element].[Attribute]) as eh2
ON ( a.ElementID = ELEMENTIDH AND NOMBREH LIKE 'Hi' AND Concat(Concat('|', a.Name), '|') LIKE CAMINOH )
/*MOMENTO INNER JOIN*/

/*MOMENTO INNER JOIN*/
INNER JOIN
	(SELECT
		ElementID as ELEMENTIDHH,
		Value_Double as HiHi,
		Name as NOMBREHH,
		Path as CAMINOHH
	FROM [Master].[Element].[Attribute]) as ehh
ON ( a.ElementID = ELEMENTIDHH AND NOMBREHH LIKE 'HiHi' AND Concat(Concat('|', a.Name), '|') LIKE CAMINOHH )
/*MOMENTO INNER JOIN*/

WHERE (
( eh.Path = '{camino}' )
AND
( 
( a.Name NOT LIKE 'LoLo' )
AND
( a.Name NOT LIKE 'Hi' )
AND
( a.Name NOT LIKE 'HiHi' )
AND
( a.Name NOT LIKE 'Alarma' )
AND
( a.Name NOT LIKE 'Detalle' )
AND
( a.Name NOT LIKE 'Unidad' )
AND
( a.Name NOT LIKE 'Activo' )
AND
( a.Name NOT LIKE 'Downtag' )
AND
( a.Name NOT LIKE 'Lo' )
AND
( a.Name NOT LIKE 'Marca%' )
AND
( a.Name NOT LIKE 'Modelo%' )
AND
( a.Name NOT LIKE 'Número%' )
AND
( a.Name NOT LIKE 'Numero%' )
AND
( a.Name NOT LIKE 'Tipo' )
 )
)

ORDER BY a.Name
