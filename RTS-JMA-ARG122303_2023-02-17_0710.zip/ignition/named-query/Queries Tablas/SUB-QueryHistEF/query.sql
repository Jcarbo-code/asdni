SELECT DISTINCT

PrimaryReferencedElementID as EVENTO,
SUBSTRING( Name,1, (INSTR(Name, 'por',1,1))-1) as DESCRIPCION,

--  TSS, SOLO TSS. COLUMNA TSS DE FECHA A STRING PARA QUE EXPORT A EXCEL FUNCIONE CORRECTAMENTE EN FORMATO 
--Max(CAST(StartTime as string)) as TSS,
--Max(StartTime) as TSS,
StartTime as TSS,
ID as EFID

FROM [Master].[EventFrame].[EventFrame] as ef





/*MOMENTO INNER JOIN*/
INNER JOIN
(SELECT	
CASE
    WHEN replace(SUBSTRING( Path,
		INSTR(Path,'\',1,6)+1, 
		Abs(INSTR(Path,'\',1,7)-INSTR(Path,'\',1,6))
	) ,'\','' ) = '' THEN Name
    ELSE replace(SUBSTRING( Path,
		INSTR(Path,'\',1,6)+1, 
		Abs(INSTR(Path,'\',1,7)-INSTR(Path,'\',1,6))
	) ,'\','' )
END as ACTIVO,
ElementID as ElementIDe
FROM [Master].[Element].[ElementHierarchy]) as em
ON ef.PrimaryReferencedElementID = ElementIDe
/*MOMENTO INNER JOIN*/

		-- {Region}\{Pais}\{Distrito}\{Yacimiento}\{Locacion}
WHERE (
		( ACTIVO LIKE '{Activo}' ) 
		AND
		( StartTime > '{stTime}' )
		
		AND
		( StartTime < '{endTime}' )
		
		AND (
		( replace(SUBSTRING( Name,1, Abs(INSTR(Name,' ',1,1))),' ', '') LIKE 'Paro' AND {CHKBX_varParo} = 1 ) OR 
		( replace(SUBSTRING( Name,1, Abs(INSTR(Name,' ',1,1))),' ', '') LIKE 'Condiciones' AND {CHKBX_varCINS} = 1 ) OR 
		( replace(SUBSTRING( Name,1, Abs(INSTR(Name,' ',1,1))),' ', '') LIKE 'Conectividad' AND {CHKBX_varCtvd} = 1 ) OR 
		( replace(SUBSTRING( Name,1, Abs(INSTR(Name,' ',1,1))),' ', '') LIKE 'Alarma' AND {CHKBX_varAlrms} = 1 ) 
		)
		
		)

Order by StartTime
--GROUP BY ef.PrimaryReferencedElementID, ea.Element, ea.Value_String, em.ElementID, ea.Description, em.Path, ea.Path