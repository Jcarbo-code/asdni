SELECT 

CASE
	WHEN Count(PrimaryReferencedElementID) >= 0 THEN STRING(DAY(StartTime))
	ELSE '0'
END as DIAELEGIDO,

CASE
WHEN Double(Sum(Duration),minute) >= 1440 then string(min(StartTime))
ELSE STRING(DOUBLE(Sum(Duration),minute)) 
END as OFFTIME,

CASE
WHEN Double(Sum(Duration),minute) >= 1440 then string(max(EndTime))
ELSE ' '
END as NEXTTIME

FROM [Master].[EventFrame].[EventFrame] as ef

INNER JOIN
(SELECT
CASE
    WHEN replace(SUBSTRING( Path,
		INSTR(Path,'\',1,6)+1, 
		Abs(INSTR(Path,'\',1,7)-INSTR(Path,'\',1,6))
	) ,'\','' ) = '' THEN Name
    ELSE replace(SUBSTRING( Path,
		INSTR(Path,'\',1,6)+1, 
		Abs(INSTR(Path,'\',1,7)-INSTR(Path,'\',1,6))
	) ,'\','' )
END as ACTIVO,
ElementID as ElementIDem
FROM [Master].[Element].[ElementHierarchy]
) as em
ON ef.PrimaryReferencedElementID = ElementIDem

WHERE (
		( StartTime > '{stTime}' )
		AND
		( replace(SUBSTRING( Name,1, Abs(INSTR(Name,' ',1,1))),' ', '') = 'Paro' )
		AND
		ACTIVO = '{Activo}'
		)
		
GROUP BY DAY(StartTime)