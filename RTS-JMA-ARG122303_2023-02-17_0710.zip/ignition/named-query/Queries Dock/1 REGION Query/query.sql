SELECT DISTINCT

replace(SUBSTRING( em.Path,
		INSTR(em.Path,'\',1,1)+1, 
		Abs(INSTR(em.Path,'\',1,2)-INSTR(em.Path,'\',1,1))
	) ,'\','' ) as REGION 

FROM [Master].[Element].[ElementHierarchy] as em

WHERE ( Level = 1 )
ORDER BY REGION