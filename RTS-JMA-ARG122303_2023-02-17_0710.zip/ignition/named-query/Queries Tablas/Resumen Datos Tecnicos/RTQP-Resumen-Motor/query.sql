SELECT	
		UPPER(Marca_Motor) AS Marca_Motor,
		UPPER(Modelo_Motor) AS Modelo_Motor
FROM [Master].[Element].[ElementHierarchy] as em
	
/*MOMENTO INNER JOIN*/
INNER JOIN
	(SELECT
		ElementID as ELEMENTIDHH,
		Value_String as Marca_Motor,
		Name as NOMBREHH
	FROM [Master].[Element].[Attribute]) as ehh
ON ( em.ElementID = ELEMENTIDHH AND NOMBREHH LIKE 'Marca {what}')
/*MOMENTO INNER JOIN*/

/*MOMENTO INNER JOIN*/
INNER JOIN
	(SELECT
		ElementID as ELEMENTIDHI,
		Value_String as Modelo_Motor,
		Name as NOMBREHI
	FROM [Master].[Element].[Attribute]) as ehi
ON ( em.ElementID = ELEMENTIDHI AND NOMBREHI LIKE 'Modelo {what}')
/*MOMENTO INNER JOIN*/

Where (
Marca_Motor is not null
AND
	(
		(
		( {Region} AND {level_var}=0 ) --REGION
		OR
		( {Pais} AND {level_var}=1 ) 
		OR
		( {Distrito} AND {level_var}=2 ) 
		OR
		( {Yacimiento} AND {level_var}=3 ) --REGION
		OR
		( {Locacion} AND {level_var}=4 ) 
		OR
		( ({Activo}) AND {level_var}=5 ) 
		)
	)
)
ORDER BY Marca_Motor