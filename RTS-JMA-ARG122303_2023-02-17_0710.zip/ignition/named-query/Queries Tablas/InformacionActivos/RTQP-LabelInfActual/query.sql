-- Attribute table.
-- Returns element attributes.VLCD, POTMOTOR, CAUDALGCOMP, CONSUMO, HDMT, PSUC, PRESDESC, FACTOR 
SELECT DISTINCT
concat(string(VLCD),concat(' ', uom1)) as VLCD, 
concat(string(POTMOTOR),concat(' ', uom2)) as POTMOTOR, 
concat(string(CAUDALGCOMP),concat(' ', uom3)) as CAUDALGCOMP, 
concat(string(CONSUMO),concat(' ', uom4)) as CONSUMO, 
concat(string(HDMT),concat(' ', uom5)) as HDMT, 
concat(string(PSUC),concat(' ', uom6)) as PSUC, 
concat(string(PRESDESC),concat(' ', uom7)) as PRESDESC, 
concat(string(FACTOR),concat(' ', uom8)) as FACTOR 

FROM [Master].[Element].[Attribute] as ea

/*MOMENTO INNER JOIN*/
LEFT JOIN
	(SELECT	
		Path as RUTA,
		ElementID as ELEMENTIDIJ,
		CASE
		    WHEN replace(SUBSTRING( Path,
				INSTR(Path,'\',1,6)+1, 
				Abs(INSTR(Path,'\',1,7)-INSTR(Path,'\',1,6))
			) ,'\','' ) = '' THEN Name
		    ELSE replace(SUBSTRING( Path,
				INSTR(Path,'\',1,6)+1, 
				Abs(INSTR(Path,'\',1,7)-INSTR(Path,'\',1,6))
			) ,'\','' )
		END as ACTIVO
	FROM [Master].[Element].[ElementHierarchy]) as em
ON ea.ElementID = ELEMENTIDIJ
/*MOMENTO INNER JOIN*/

/*MOMENTO INNER JOIN*/
LEFT JOIN
	(SELECT
		ElementID as ELEMENTIDHH,
		UnitOfMeasure as uom1,
		Value as VLCD,
		Name as NOMBREHH,
		Path as CAMINOHH
	FROM [Master].[Element].[Attribute]) as ehh
ON ( ea.ElementID = ELEMENTIDHH AND NOMBREHH = 'Velocidad' ) --1
/*MOMENTO INNER JOIN*/

/*MOMENTO INNER JOIN*/
LEFT JOIN
	(SELECT
		ElementID as ELEMENTIDPP,
		Value as POTMOTOR,
		UnitOfMeasure as uom2,
		Name as NOMBREPP,
		Path as CAMINOPP
	FROM [Master].[Element].[Attribute]) as epp
ON ( ea.ElementID = ELEMENTIDPP AND NOMBREPP LIKE 'Potencia para Compresión' ) --2
/*MOMENTO INNER JOIN*/

/*MOMENTO INNER JOIN*/
LEFT JOIN
	(SELECT
		ElementID as ELEMENTIDLL,
		Value as CAUDALGCOMP,
		UnitOfMeasure as uom3,
		Name as NOMBRELL,
		Path as CAMINOLL
	FROM [Master].[Element].[Attribute]) as ell
ON ( ea.ElementID = ELEMENTIDLL AND NOMBRELL LIKE 'Caudal de Gas Comprimido' ) --3
/*MOMENTO INNER JOIN*/

/*MOMENTO INNER JOIN*/
LEFT JOIN
	(SELECT
		ElementID as ELEMENTIDL,
		Value as CONSUMO,
		UnitOfMeasure as uom4,
		Name as NOMBRE,
		Path as CAMINO
	FROM [Master].[Element].[Attribute]) as el
ON ( ea.ElementID = ELEMENTIDL AND NOMBRE LIKE 'Consumo Específico del Motor' ) --4
/*MOMENTO INNER JOIN*/

/*MOMENTO INNER JOIN*/
LEFT JOIN
	(SELECT
		ElementID as ELEMENTIDSS,
		Value as HDMT,
		UnitOfMeasure as uom5,
		Name as NOMBRESS,
		Path as CAMINOSS
	FROM [Master].[Element].[Attribute]) as ess
ON ( ea.ElementID = ELEMENTIDSS AND NOMBRESS LIKE 'Horas de Marcha Totales' ) --5
/*MOMENTO INNER JOIN*/

/*MOMENTO INNER JOIN*/
LEFT JOIN
	(SELECT
		ElementID as ELEMENTIDH,
		Value as PSUC,
		Name as NOMBREH,
		UnitOfMeasure as uom6,
		Path as CAMINOH
	FROM [Master].[Element].[Attribute]) as eh
ON ( ea.ElementID = ELEMENTIDH AND NOMBREH LIKE 'Presión de Succión' ) --6
/*MOMENTO INNER JOIN*/

/*MOMENTO INNER JOIN*/
LEFT JOIN
	(SELECT
		ElementID as ELEMENTIDTT,
		Value as PRESDESC,
		UnitOfMeasure as uom7,
		Name as NOMBRETT,
		Path as CAMINOTT
	FROM [Master].[Element].[Attribute]) as ett
ON ( ea.ElementID = ELEMENTIDTT AND NOMBRETT LIKE 'Presión Descarga Final Compresor' ) --7
/*MOMENTO INNER JOIN*/

/*MOMENTO INNER JOIN*/
LEFT JOIN
	(SELECT
		ElementID as ELEMENTIDCC,
		Value as FACTOR,
		Name as NOMBRECC,
		UnitOfMeasure as uom8,
		Path as CAMINOCC
	FROM [Master].[Element].[Attribute]) as ecc
ON ( ea.ElementID = ELEMENTIDCC AND NOMBRECC LIKE 'Factor de Carga Motor' ) --7
/*MOMENTO INNER JOIN*/




WHERE (

( ACTIVO LIKE '{myActivo}' )
AND
(
( Name LIKE 'Velocidad' )
OR
( Name LIKE 'Potencia para Compresión' ) --2
OR
( Name LIKE 'Caudal de Gas Comprimido' ) --3
OR
( Name LIKE 'Consumo Específico del Motor' ) --4
OR
( Name LIKE 'Horas de Marcha Totales' ) --5
OR
( Name LIKE 'Presión de Succión' ) --6
OR
( Name LIKE 'Presión Descarga Final Compresor' ) --7
OR
( Name LIKE 'Factor de Carga Motor' ) --8
)

)

