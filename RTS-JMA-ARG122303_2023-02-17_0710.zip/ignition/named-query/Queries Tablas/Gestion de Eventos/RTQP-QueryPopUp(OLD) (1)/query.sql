/*QUERY PARA POPUP*/-- Attribute table.
-- Returns element attributes.
SELECT
ea.Path as PRIMERCOLUMNAPOPUP,
ea.TimeStamp,
ea.ElementID

FROM [Master].[Element].[Attribute] as ea

INNER JOIN
	[Master].[Element].[ElementHierarchy] as em
ON ea.ElementID = em.ElementID

WHERE ea.ElementID='{PopUp_ElementID}'

AND
( ea.Name = 'Detalle' )

