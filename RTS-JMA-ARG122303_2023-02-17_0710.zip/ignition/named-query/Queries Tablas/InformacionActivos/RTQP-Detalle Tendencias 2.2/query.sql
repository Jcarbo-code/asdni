-- GetSampledValues (@AttributeID, @StartTime, @EndTime, @TimeStep) table-valued function.
-- Calculates element attribute interpolations in the specified time range.
SELECT TOP 15
[s].TimeStamp,
s.Value_Double
--e.ElementName, 
--ea.Name,

FROM
(
	SELECT TOP 5 Name ElementName, ID ElementID
	FROM [Master].[Element].[Element]
	ORDER BY Name
) e
INNER JOIN [Master].[Element].[Attribute] ea ON ea.ElementID = e.ElementID
CROSS APPLY [Master].[Element].[GetSampledValues]
(
	ea.ID, -- @AttributeID
	N'*-30m', -- @StartTime
	N'*', -- @EndTime
	N'30s' -- @TimeStep
) s

WHERE ElementName LIKE '15156c' and ( Name LIKE 'Horas de Marcha Totales' )