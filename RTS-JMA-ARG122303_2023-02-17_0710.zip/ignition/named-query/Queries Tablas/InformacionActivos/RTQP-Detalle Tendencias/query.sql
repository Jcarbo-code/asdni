-- GetSampledValues (@AttributeID, @StartTime, @EndTime, @TimeStep) table-valued function.
-- Calculates element attribute interpolations in the specified time range.
SELECT 
[s].TimeStamp as time,
s.Value_Double as valorcin
--e.ElementName
--ea.Name 

FROM
(
	SELECT TOP 5 Name ElementName, ID ElementID
	FROM [Master].[Element].[Element]
	ORDER BY Name
) e
INNER JOIN [Master].[Element].[Attribute] ea ON ea.ElementID = e.ElementID
CROSS APPLY [Master].[Element].[GetSampledValues]
(
	ea.ID, -- @AttributeID
	N'{stTime}', -- @StartTime
	N'{endTime}', -- @EndTime
	N'{myInterv}' -- @TimeStep
) s

WHERE ElementName LIKE '{myActivo}' and ( Name LIKE '{myAtri}' )