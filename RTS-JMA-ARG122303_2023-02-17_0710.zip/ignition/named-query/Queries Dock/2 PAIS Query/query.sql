SELECT DISTINCT
	
replace(SUBSTRING( em.Path,
		INSTR(em.Path,'\',1,2)+1, 
		Abs(INSTR(em.Path,'\',1,3)-INSTR(em.Path,'\',1,2))
	) ,'\','' ) as PAIS

FROM [Master].[Element].[ElementHierarchy] as em 

WHERE (
		( Level = 2 )
		
		  AND
		  
		  ( {var_REG} ) --em.Path
	)
	
ORDER by PAIS