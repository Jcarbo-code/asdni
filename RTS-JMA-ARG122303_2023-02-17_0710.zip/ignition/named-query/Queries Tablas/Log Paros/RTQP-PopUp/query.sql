SELECT DISTINCT

ef.StartTime as Inicio, 
ef.EndTime as Fin,
ef.Name as Descripcion,
ef.Duration,
ACTIVO,
ef.ID as EFID
FROM [Master].[EventFrame].[EventFrame] AS ef

INNER JOIN
(SELECT 
CASE
    WHEN replace(SUBSTRING( Path,
		INSTR(Path,'\',1,6)+1, 
		Abs(INSTR(Path,'\',1,7)-INSTR(Path,'\',1,6))
	) ,'\','' ) = '' THEN Name
    ELSE replace(SUBSTRING( Path,
		INSTR(Path,'\',1,6)+1, 
		Abs(INSTR(Path,'\',1,7)-INSTR(Path,'\',1,6))
	) ,'\','' )
END as ACTIVO,
ElementID as Elementem
FROM [Master].[Element].[ElementHierarchy]) as em
ON Elementem = ef.PrimaryReferencedElementID 
/*MOMENTO INNER JOIN*/ --

WHERE ( ( {distinto} ) 
		AND 
		( ACTIVO = '{myActivo}' )
		AND
		( ef.Acknowledged IS NULL )
	)
ORDER BY StartTime Desc