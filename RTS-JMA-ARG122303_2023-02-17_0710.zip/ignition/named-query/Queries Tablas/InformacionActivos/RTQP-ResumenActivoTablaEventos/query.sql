SELECT DISTINCT
' ' as EVENTO,
SUBSTRING( Name,1, (INSTR(Name, 'por',1,1))-1) as DESCRIPCION,
Max(StartTime) as TSS,
COUNT(ID) as EFIDTOTAL,
String(SUM(Duration)) as tiempoac,
ACTIVO

FROM [Master].[EventFrame].[EventFrame] as ef

/*MOMENTO INNER JOIN*/
INNER JOIN
(SELECT 
CASE
    WHEN replace(SUBSTRING( Path,
		INSTR(Path,'\',1,6)+1, 
		Abs(INSTR(Path,'\',1,7)-INSTR(Path,'\',1,6))
	) ,'\','' ) = '' THEN Name
    ELSE replace(SUBSTRING( Path,
		INSTR(Path,'\',1,6)+1, 
		Abs(INSTR(Path,'\',1,7)-INSTR(Path,'\',1,6))
	) ,'\','' )
END as ACTIVO,
ElementID as Elementem
FROM [Master].[Element].[ElementHierarchy]
) as em

ON Elementem = ef.PrimaryReferencedElementID
/*MOMENTO INNER JOIN*/

WHERE ACTIVO LIKE '{Activo}'
GROUP BY SUBSTRING( ef.Name,1, (INSTR(ef.Name, 'por',1,1))-1), ACTIVO
Order by TSS

