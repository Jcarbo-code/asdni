SELECT DISTINCT
replace(SUBSTRING( Path,
		INSTR(Path,'\',1,3)+1, 
		Abs(INSTR(Path,'\',1,4)-INSTR(Path,'\',1,3))
		) ,'\','' ) as DISTRITO,
		
replace(SUBSTRING( em.Path,
		INSTR(em.Path,'\',1,4)+1, 
		Abs(INSTR(em.Path,'\',1,5)-INSTR(em.Path,'\',1,4))
	) ,'\','' ) as YACIMIENTO,
CASE
    WHEN replace(SUBSTRING( em.Path,
		INSTR(em.Path,'\',1,6)+1, 
		Abs(INSTR(em.Path,'\',1,7)-INSTR(em.Path,'\',1,6))
	) ,'\','' ) = '' THEN em.Name
    ELSE replace(SUBSTRING( em.Path,
		INSTR(em.Path,'\',1,6)+1, 
		Abs(INSTR(em.Path,'\',1,7)-INSTR(em.Path,'\',1,6))
	) ,'\','' )
END as ACTIVO,

String(ESTADOIJ) as ESTADOIJ

--em.ElementID as ElementID

FROM [Master].[Element].[ElementHierarchy] as em


LEFT JOIN
	(SELECT 
	Value as ESTADOIJ,
	Name as NAMEIJ,
	Element as ELEMENTIJ,
	ElementID
	FROM [Master].[Element].[Attribute]) as ea
ON (ea.ElementID = em.ElementID AND NAMEIJ = 'Estado Equipo')
/*MOMENTO INNER JOIN*/

WHERE ESTADOIJ is not null 
AND

	(
		( {Region} AND {level_var}=0 ) --REGION
		OR
		( {Pais} AND {level_var}=1 ) 
		OR
		( {Distrito} AND {level_var}=2 ) 
		OR
		( {Yacimiento} AND {level_var}=3 ) --REGION
		OR
		( {Locacion} AND {level_var}=4 ) 
		OR
		( {Activo} AND {level_var}=5 ) 
		)