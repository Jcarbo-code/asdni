-- Attribute table.
-- Returns element attributes.
SELECT Concat(Name,Concat(' - ', Element)) as Name, Description, UnitOfMeasure, Value
FROM [Master].[Element].[Attribute] as ea

/*MOMENTO INNER JOIN*/
INNER JOIN
	(SELECT	
		Path as RUTA,
		ElementID as ELEMENTIDIJ,
		CASE
		    WHEN replace(SUBSTRING( Path,
				INSTR(Path,'\',1,6)+1, 
				Abs(INSTR(Path,'\',1,7)-INSTR(Path,'\',1,6))
			) ,'\','' ) = '' THEN Name
		    ELSE replace(SUBSTRING( Path,
				INSTR(Path,'\',1,6)+1, 
				Abs(INSTR(Path,'\',1,7)-INSTR(Path,'\',1,6))
			) ,'\','' )
		END as ACTIVO
	FROM [Master].[Element].[ElementHierarchy]) as em
ON ea.ElementID = ELEMENTIDIJ
/*MOMENTO INNER JOIN*/




WHERE (
( ACTIVO LIKE '{myActivo}' )
AND
( UnitOfMeasure is not null)
AND
( Name NOT LIKE 'LoLo' )
AND
( Name NOT LIKE 'Hi' )
AND
( Name NOT LIKE 'HiHi' )
AND
( Name NOT LIKE 'Alarma' )
AND
( Name NOT LIKE 'Detalle' )
AND
( Name NOT LIKE 'Unidad' )
AND
( Name NOT LIKE 'Activo' )
AND
( Name NOT LIKE 'Downtag' )
AND
( Name NOT LIKE 'Lo' )

)